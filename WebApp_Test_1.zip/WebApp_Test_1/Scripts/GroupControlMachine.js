﻿function ConnectToHub() {
  
    chat = $.connection.myHub;
    chat.client.broadcastMessage = function (name, message) {
        console.log(message);
        var checkboxlist = $('.ipaddressclassname');
        var data = message.split(',');
        if (data.indexOf("StatusData") != -1) {
            $(checkboxlist).each(function () {
                if ($(this).prop("value") == name) {

                    if (data[2] == "Online") {
                        $(this).closest('.eqp-ctrl-pannel').find(".status-dot").prop("background-color", "green");
                        this.checked = true;
                    }

                    else {
                        $(this).closest('.eqp-ctrl-pannel').find(".status-dot").prop("background-color", "orange");
                        this.checked = false;
                    }


                    if (data[5] == "On")
                        $(this).closest('.eqp-ctrl-pannel').find(".computerclass").removeClass(".j-eqm-*").addClass("j-eqm-green");
                    else
                        $(this).closest('.eqp-ctrl-pannel').find(".computerclass").removeClass(".j-eqm-*").addClass("j-eqm-red");
                    if (data[6] == "On")
                        $(this).closest('.eqp-ctrl-pannel').find(".projectorclass").removeClass(".j-eqm-*").addClass("j-eqm-green");
                    else
                        $(this).closest('.eqp-ctrl-pannel').find(".projectorclass").removeClass(".j-eqm-*").addClass("j-eqm-red");
                    if (data[8] == "On")
                        $(this).closest('.eqp-ctrl-pannel').find(".podiumcurtainclass").removeClass(".j-eqm-*").addClass("j-eqm-green");
                    else
                        $(this).closest('.eqp-ctrl-pannel').find(".podiumcurtainclass").removeClass(".j-eqm-*").addClass("j-eqm-red");
                    if (data[10] == "On")
                        $(this).closest('.eqp-ctrl-pannel').find(".lightclass1").removeClass(".j-eqm-*").addClass("j-eqm-green");
                    else
                        $(this).closest('.eqp-ctrl-pannel').find(".lightclass1").removeClass(".j-eqm-*").addClass("j-eqm-red");
                    if (data[15] == "On")
                        $(this).closest('.eqp-ctrl-pannel').find(".podiumlightclass").removeClass(".j-eqm-*").addClass("j-eqm-green");
                    else
                        $(this).closest('.eqp-ctrl-pannel').find(".podiumlightclass").removeClass(".j-eqm-*").addClass("j-eqm-red");
                    if (data[12] == "Unlock")
                        $(this).closest('.eqp-ctrl-pannel').find(".systemlockclass").removeClass(".j-eqm-*").addClass("j-eqm-green");
                    else
                        $(this).closest('.eqp-ctrl-pannel').find(".systemlockclass").removeClass(".j-eqm-*").addClass("j-eqm-red");

                }
            })
        }
       

    };
    $.connection.hub.start({ waitForPageLoad: false }).done(function () {
        console.log("connection doen ");
        $(".projectorclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');
            if ($(this).hasClass("j-eqm-green"))
                chat.server.sendControlKeys(ip, "FF FE 34 01 00 FF FF FF FF A0 A1 A2 A3");
            else //if ($(this).hasClass("j-eqm-red"))
                chat.server.sendControlKeys(ip, "FF FE 34 01 01 FF FF FF FF A0 A1 A2 A3");
        })
       
        $(".computerclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');
            if ($(this).hasClass("j-eqm-green"))
                chat.server.sendControlKeys(ip, "FF FE 33 01 00 FF FF FF FF A0 A1 A2 A3");
            else //if ($(this).hasClass("j-eqm-red"))
                chat.server.sendControlKeys(ip, "FF FE 33 01 01 FF FF FF FF A0 A1 A2 A3");
        });
        $(".volumeclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');
            if ($(this).hasClass("j-eqm-green"))
                chat.server.sendControlKeys(ip, "FF FE 33 01 00 FF FF FF FF A0 A1 A2 A3");
            else //if ($(this).hasClass("j-eqm-red"))
                chat.server.sendControlKeys(ip, "FF FE 33 01 01 FF FF FF FF A0 A1 A2 A3");
        });
        $(".projectorclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');

        });
        $(".signalclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');

        });
        $(".systemlockclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');

        });
        $(".lightclass1").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');

        });
        $(".classroomcurtainsclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');

        });
        $(".acclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');

        });
        $(".podiumlightclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');

        });
        $(".podiumcurtainclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');

        });
        $(".freshairclass").on("click", function () {
            var ip = $(this).closest('.eqp-ctrl-pannel').find('input[name="classipAddress"]').prop('value');
            chat.server.sendControlKeys(ip, "FF FE 37 01 01 FF FF FF FF A0 A1 A2 A3");
        });
        $('.ipaddressclassname').on("click", function () {
            var ip = $(this).prop('value');
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "FF FE 37 01 01 FF FF FF FF A0 A1 A2 A3");
            else //if ($(this).hasClass("j-eqm-red"))
                chat.server.sendControlKeys(ip, "FF FE 37 01 00 FF FF FF FF A0 A1 A2 A3");
            
        });
        $('.batchbootup').on("click", function () {
            var iplist = [];
            $('input[name="classipAddress"]:checked').each(function () {
               iplist.push($(this).val());
            })
            for (i = 0; i < iplist.length; i++)
                chat.server.sendControlKeys(iplist[i], "FF FE 37 01 01 FF FF FF FF A0 A1 A2 A3");

        });
        $('.batchshutdown').on("click", function () {
            var iplist = [];
            $('input[name="classipAddress"]:checked').each(function () {
                iplist.push($(this).val());
            })
            for (i = 0; i < iplist.length; i++)            
                chat.server.sendControlKeys(ip, "FF FE 37 01 00 FF FF FF FF A0 A1 A2 A3");

        });

    });
}
ConnectToHub();