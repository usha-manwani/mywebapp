﻿$(function () {
    var oldvol = 0, micoldvol = 0, wirelessoldvol = 0;
    chat = $.connection.myHub;
    var ip = $("#controlip").val();
    console.log("ip of control: " + ip);
    chat.client.broadcastMessage = function (name, message) {

        if (name == ip) {
            var data = message.split(',');
            if (data.indexOf("StatusData") != -1) {

                if (data[3] == "Open") $(".systemonoff").checked = true;
                else $(".systemonoff").checked = true;


                if (data[5] == "On")
                    $(".computeronoff").checked = true;
                else
                    $(".computeronoff").checked = false;

                if (data[6] == "On")
                    $(".projector1").checked = true;
                else
                    $(".projector1").checked = false;
                if (data[9] == "On") {
                    $(".screen1").find(".fa-arrow-down").parent().addClass("active");
                    $(".screen1").find(".fa-arrow-up").parent().removeClass("active");
                    $(".screen1").find(".fa-pause").parent().removeClass("active");
                }

                else {
                    $(".screen1").find(".fa-arrow-down").parent().removeClass("active");
                    $(".screen1").find(".fa-arrow-up").parent().addClass("active");
                    $(".screen1").find(".fa-pause").parent().removeClass("active");
                }
                if (data[10] == "On")
                    $(".lightcontrol1").checked = true;
                else
                    $(".lightcontrol1").checked = false;
                if (data[15] == "On")
                    $(".lightcontrol2").checked = true;
                else
                    $(".lightcontrol2").checked = false;
                if (data[12] == "Unlock")
                    $(".panellockunlock").checked = false;
                else
                    $(".panellockunlock").checked = false;

                if (data[11] == "laptop")
                    $('input[name="c001-2"]').find("notebookvga").checked = true;
                else if (data[11] == "desktop")
                    $('input[name="c001-2"]').find("computersignal").checked = true;
                else if (data[11] == "other")
                    $('input[name="c001-2"]').find("digitaldevice").checked = true;
                else
                    $('input[name="c001-2"]').find("digitaldevice").checked = true;

            }

            else {
                if (data[0] == "projectoron") $(".projector1").checked = true;
                else $(".projector1").checked = false;

                if (data[0] == "computeron") $(".computeronoff").checked = true;
                else $(".computeronoff").checked = false;
                if (data[3] == "systemon") $(".systemonoff").checked = true;
                else $(".systemonoff").checked = true;
                if (data.indexOf("sound" != -1)) {
                    if (data[0] == "wiredmic") {
                        if (data[1] == "increase")
                        {
                            $(".wiredmicvolume").val($(".wiredmicvolume").val() + 10)  ;

                        }
                        else
                            $(".wiredmicvolume").val($(".wiredmicvolume").val() - 10) ;
                    }
                    if (data[0] == "wirelessmic") {
                        if (data[1] == "increase")
                        {
                            $(".wirelessmicvolume").val($(".wirelessmicvolume").val() + 10) ;

                        }
                        else
                            $(".wirelessmicvolume").val($(".wirelessmicvolume").val() - 10) ;
                    }
                    if (data[0] == "volume") {
                        if (data[1] == "increase")
                        {
                            $(".volume").val($(".volume").val() + 10) ;

                        }
                        else
                            $(".volume").val($(".volume").val() - 10) ;
                    }
                }
                if (data[0] == "screen1fall") {
                    $(".screen1").find(".fa-arrow-down").parent().addClass("active");
                    $(".screen1").find(".fa-arrow-up").parent().removeClass("active");
                    $(".screen1").find(".fa-pause").parent().removeClass("active");
                }
                else {
                    $(".screen1").find(".fa-arrow-down").parent().removeClass("active");
                    $(".screen1").find(".fa-arrow-up").parent().addClass("active");
                    $(".screen1").find(".fa-pause").parent().removeClass("active");
                }

                if (data[0] == "screen2fall") {
                    $(".screen2").find(".fa-arrow-down").parent().addClass("active");
                    $(".screen2").find(".fa-arrow-up").parent().removeClass("active");
                    $(".screen2").find(".fa-pause").parent().removeClass("active");
                }
                else {
                    $(".screen2").find(".fa-arrow-down").parent().removeClass("active");
                    $(".screen2").find(".fa-arrow-up").parent().addClass("active");
                    $(".screen2").find(".fa-pause").parent().removeClass("active");
                }

                if (data[0] == "frontlighton")
                    $(".lightcontrol1").checked = true;
                else if (data[0] == "frontlightoff")
                    $(".lightcontrol1").checked = false;
                else if (data[0] == "rearlighton")
                    $(".lightcontrol2").checked = true;
                else
                    $(".lightcontrol2").checked = false;

                if (data[0] == "signalsourcelaptop")
                    $('input[name="c001-2"]').find("notebookvga").checked = true;
                else if (data[0] == "signalsourcedesktop")
                    $('input[name="c001-2"]').find("computersignal").checked = true;
                else if (data[11] == "signalsourcedigitalstand")
                    $('input[name="c001-2"]').find("digitaldevice").checked = true;
                else
                    $('input[name="c001-2"]').find("digitaldevice").checked = true;

            }
        }

    };
    $.connection.hub.start({ waitForPageLoad: false }).done(function () {
        console.log("connection to signalR done ");
        //system control
        $(".systemonoff").on("click", function () {
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "FF FE 37 01 01 FF FF FF FF A0 A1 A2 A3");//system on
            else
                chat.server.sendControlKeys(ip, "FF FE 37 01 00 FF FF FF FF A0 A1 A2 A3");//system off
        });
        $(".computeronoff").on("click", function () {

            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "FF FE 33 01 01 FF FF FF FF A0 A1 A2 A3");//computer on
            else
                chat.server.sendControlKeys(ip, "FF FE 33 01 00 FF FF FF FF A0 A1 A2 A3");//computer off
        });
        $(".panellockunlock").on("click", function () {
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "FF FE 42 01 00 FF FF FF FF A0 A1 A2 A3");//unlock
            else
                chat.server.sendControlKeys(ip, "FF FE 42 01 02 FF FF FF FF A0 A1 A2 A3");//lock
        });

        //sound control
        $(".volume").on("change", function () {
            var newvol = $(this).val();
            if (oldvol > newvol) {
                oldvol = newvol;
                chat.server.sendControlKeys(ip, "FF FE 49 02 03 02 FF FF FF FF A0 A1 A2 A3");//decrease vol
            }
            else if (oldvol < newvol) {
                oldvol = newvol;
                chat.server.sendControlKeys(ip, "FF FE 49 02 03 01 FF FF FF FF A0 A1 A2 A3");//increase vol
            }

        });
        $(".wiredmicvolume").on("change", function () {
            $(".wiredmicvolume").val($(".wiredmicvolume").val() + 10);
            var newvol = $(this).val();
            if (oldvol > newvol) {
                oldvol = newvol;
                chat.server.sendControlKeys(ip, "FF FE 49 02 01 02 FF FF FF FF A0 A1 A2 A3");//decrease vol
            }
            else if (oldvol < newvol) {
                oldvol = newvol;
                chat.server.sendControlKeys(ip, "FF FE 49 02 01 01 FF FF FF FF A0 A1 A2 A3");//increase vol
            }

        });
        $(".wirelessmicvolume").on("change", function () {
            var newvol = $(this).val();
            if (oldvol > newvol) {
                oldvol = newvol;
                chat.server.sendControlKeys(ip, "FF FE 49 02 02 02 FF FF FF FF A0 A1 A2 A3");//decrease vol
            }
            else if (oldvol < newvol) {
                oldvol = newvol;
                chat.server.sendControlKeys(ip, "FF FE 49 02 02 01 FF FF FF FF A0 A1 A2 A3");//increase vol
            }

        });

        //screen control
        $(".screen1").on("click", function () {
            if ($(this).find('.fa-arrow-up').length != 0) {
                chat.server.sendControlKeys(ip, "FF FE 32 01 02 FF FF FF FF A0 A1 A2 A3");//screen up
            }
            else if ($(this).find('.fa-pause').length != 0) {
                chat.server.sendControlKeys(ip, "");//screen pause not done
            }
            else if ($(this).find('.fa-arrow-down').length != 0) {
                chat.server.sendControlKeys(ip, "FF FE 32 01 02 FF FF FF FF A0 A1 A2 A3");//screen down
            }

        });
        $(".screen2").on("click", function () {
            if ($(this).find('.fa-arrow-up').length != 0) {
                chat.server.sendControlKeys(ip, "FF FE 35 01 02 FF FF FF FF A0 A1 A2 A3");//screen up
            }
            else if ($(this).find('.fa-pause').length != 0) {
                chat.server.sendControlKeys(ip, "");//screen pause not done
            }
            else if ($(this).find('.fa-arrow-down').length != 0) {
                chat.server.sendControlKeys(ip, "FF FE 35 01 02 FF FF FF FF A0 A1 A2 A3");//screen down
            }

        });

        //light control
        $('.lightcontrol1').on("click", function () {
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "FF FE 46 02 01 01 FF FF FF FF A0 A1 A2 A3");// front light on
            else
                chat.server.sendControlKeys(ip, "FF FE 46 02 01 02 FF FF FF FF A0 A1 A2 A3");//front light off

        });
        $('.lightcontrol2').on("click", function () {
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "FF FE 46 02 02 01 FF FF FF FF A0 A1 A2 A3");//rear light on
            else
                chat.server.sendControlKeys(ip, "FF FE 46 02 02 02 FF FF FF FF A0 A1 A2 A3");//rear light off

        });

        //projector control
        $(".projector1").on("click", function () {
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "FF FE 39 01 01 FF FF FF FF A0 A1 A2 A3");//projector on
            else
                chat.server.sendControlKeys(ip, "FF FE 39 01 02 FF FF FF FF A0 A1 A2 A3");//projector off

        });
        $(".projector2").on("click", function () { //not done
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "FF FE 39 01 01 FF FF FF FF A0 A1 A2 A3");//projector2 on
            else
                chat.server.sendControlKeys(ip, "FF FE 39 01 02 FF FF FF FF A0 A1 A2 A3");//projector2 off

        });

        //power control
        $(".powerprojector").on("click", function () { //not done
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "");//power projector on
            else
                chat.server.sendControlKeys(ip, "");//power projector off

        });
        $(".powercomputer").on("click", function () { //not done
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "");//power computer on
            else
                chat.server.sendControlKeys(ip, "");//power computeroff off
        });
        $(".powervolume").on("click", function () {//not done
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "");//power sound on
            else
                chat.server.sendControlKeys(ip, "");//power sound off
        });
        $('.powerother').on("click", function () {//not done
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "");//power other on
            else
                chat.server.sendControlKeys(ip, "");//power other off

        });

        //curtain control
        $(".curtain1").on("click", function () { //not done
            if ($(this).find('.fa-arrow-up').length != 0) {
                chat.server.sendControlKeys(ip, "");//curtain open
            }
            else if ($(this).find('.fa-pause').length != 0) {
                chat.server.sendControlKeys(ip, "");//curtain pause
            }
            else if ($(this).find('.fa-arrow-down').length != 0) {
                chat.server.sendControlKeys(ip, "");//curtain close
            }

        });
        $(".curtain2").on("click", function () { //not done
            if ($(this).find('.fa-arrow-up').length != 0) {
                chat.server.sendControlKeys(ip, "");//curtain open
            }
            else if ($(this).find('.fa-pause').length != 0) {
                chat.server.sendControlKeys(ip, "");//curtain pause
            }
            else if ($(this).find('.fa-arrow-down').length != 0) {
                chat.server.sendControlKeys(ip, "");//curtain close
            }

        });

        //AC Control
        $('.controlAc1').on("click", function () {//not done
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "");//ac on
            else
                chat.server.sendControlKeys(ip, "");//ac off

        });
        $('.controlAc2').on("click", function () {//not done
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "");//ac on
            else
                chat.server.sendControlKeys(ip, "");//ac off

        });
        $('.controlAc3').on("click", function () {//not done
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "");//ac on
            else
                chat.server.sendControlKeys(ip, "");//ac off

        });
        $('.controlAc4').on("click", function () {//not done
            if ($(this).is(':checked'))
                chat.server.sendControlKeys(ip, "");//ac on
            else
                chat.server.sendControlKeys(ip, "");//ac off

        });

        //signal cource control
        $("input[name='c001-2']").on("change", function () { //partially done, need to do more
            if ($(this).hasClass('notebookvga'))
                chat.server.sendControlKeys(ip, "FF FE 48 01 02 FF FF FF FF A0 A1 A2 A3"); // laptop
            else if ($(this).hasClass('notebookhdmi'))
                chat.server.sendControlKeys(ip, "");
            else if ($(this).hasClass('computersignal'))
                chat.server.sendControlKeys(ip, "FF FE 48 01 01 FF FF FF FF A0 A1 A2 A3"); //desktop
            else if ($(this).hasClass('digitaldevice'))
                chat.server.sendControlKeys(ip, "FF FE 48 01 03 FF FF FF FF A0 A1 A2 A3"); //digital device
        });
    });
});