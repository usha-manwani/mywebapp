#define IDI_BG_ICON                     100
